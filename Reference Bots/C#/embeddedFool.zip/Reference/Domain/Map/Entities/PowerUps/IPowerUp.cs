﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reference.Domain.Map.Entities.PowerUps
{
    public interface IPowerUp : IEntity
    {
    }
}
