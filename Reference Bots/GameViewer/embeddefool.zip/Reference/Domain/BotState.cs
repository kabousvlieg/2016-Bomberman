﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Reference.Domain.Map;

namespace Reference.Domain
{
    public class BotState
    {
        public Location PreviousNodeLocation { get; set; }
    }
}
